from django.apps import AppConfig


class CaretakerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caretaker'
